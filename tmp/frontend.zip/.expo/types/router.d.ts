/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/cartoes`; params?: Router.UnknownInputParams; } | { pathname: `/financiamentos`; params?: Router.UnknownInputParams; } | { pathname: `/gastosFixos`; params?: Router.UnknownInputParams; } | { pathname: `/gastosVariaveis`; params?: Router.UnknownInputParams; } | { pathname: `/home`; params?: Router.UnknownInputParams; } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/register`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/cartoes`; params?: Router.UnknownOutputParams; } | { pathname: `/financiamentos`; params?: Router.UnknownOutputParams; } | { pathname: `/gastosFixos`; params?: Router.UnknownOutputParams; } | { pathname: `/gastosVariaveis`; params?: Router.UnknownOutputParams; } | { pathname: `/home`; params?: Router.UnknownOutputParams; } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/register`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/cartoes${`?${string}` | `#${string}` | ''}` | `/financiamentos${`?${string}` | `#${string}` | ''}` | `/gastosFixos${`?${string}` | `#${string}` | ''}` | `/gastosVariaveis${`?${string}` | `#${string}` | ''}` | `/home${`?${string}` | `#${string}` | ''}` | `/${`?${string}` | `#${string}` | ''}` | `/register${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/cartoes`; params?: Router.UnknownInputParams; } | { pathname: `/financiamentos`; params?: Router.UnknownInputParams; } | { pathname: `/gastosFixos`; params?: Router.UnknownInputParams; } | { pathname: `/gastosVariaveis`; params?: Router.UnknownInputParams; } | { pathname: `/home`; params?: Router.UnknownInputParams; } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/register`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
    }
  }
}
