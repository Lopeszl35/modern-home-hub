export const API_URL = "http://192.168.1.6:8080";

// https://backendgestaogastos-production-7a4d.up.railway.app
