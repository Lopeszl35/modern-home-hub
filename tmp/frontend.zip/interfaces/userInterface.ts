export interface UserCadastro {
  nome: string;
  email: string;
  senha_hash: string;
  perfil_financeiro?: string;
  salario_mensal?: number;
  saldo_inicial?: number;
  saldo_atual?: number;
  data_cadastro?: string;
}

